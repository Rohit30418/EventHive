import { useMemo, useState, useEffect } from "react";
import useGetEvent from "../AdminCustomHooks/useGetEvents";
import EventCard from "../components/EventCard";
import {
  CalendarCheck,
  CalendarX,
  Filter,
  History,
  Loader2,
  Search,
  X,
} from "lucide-react";
import { ErrorState } from "../common/StateViews";
import { type EventType } from "../Types/eventType";

const categories = ["All", "Technology", "Webinar", "Music", "Art", "Sports"];

const AllEvents = () => {
  const [inputValue, setInputValue] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [category, setCategory] = useState("All");

  const { data = [], isLoading, error } = useGetEvent() as {
    data?: EventType[];
    isLoading: boolean;
    error?: string | null;
  };

  useEffect(() => {
    const timeoutId = setTimeout(() => {
      setSearchTerm(inputValue);
    }, 300);
    return () => clearTimeout(timeoutId);
  }, [inputValue]);

  const categoryOptions = useMemo(() => {
    if (!Array.isArray(data)) return categories;

    const eventCategories = data
      .map((event) => event.eventType || event.category)
      .filter(Boolean) as string[];

    return ["All", ...Array.from(new Set([...categories.slice(1), ...eventCategories]))];
  }, [data]);

  const { upcomingEvents, pastEvents, filteredCount } = useMemo(() => {
    if (!data || !Array.isArray(data)) {
      return { upcomingEvents: [], pastEvents: [], filteredCount: 0 };
    }

    const query = searchTerm.trim().toLowerCase();

    const searchable = data.filter((event) => {
      const matchesSearch = query
        ? [
            event.EventName,
            event.eventType,
            event.category,
            event.location,
            event.BannerTagLine,
          ]
            .filter(Boolean)
            .some((value) => String(value).toLowerCase().includes(query))
        : true;

      const eventCategory = event.eventType || event.category || "Event";

      const matchesCategory =
        category === "All" ||
        eventCategory.toLowerCase() === category.toLowerCase();

      return matchesSearch && matchesCategory;
    });

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const upcoming: EventType[] = [];
    const past: EventType[] = [];

    searchable.forEach((event) => {
      if (!event.eventDate) return;

      const eventDate = new Date(event.eventDate);
      if (Number.isNaN(eventDate.getTime())) return;

      if (eventDate >= today) upcoming.push(event);
      else past.push(event);
    });

    upcoming.sort(
      (a, b) => new Date(a.eventDate).getTime() - new Date(b.eventDate).getTime()
    );

    past.sort(
      (a, b) => new Date(b.eventDate).getTime() - new Date(a.eventDate).getTime()
    );

    return {
      upcomingEvents: upcoming,
      pastEvents: past,
      filteredCount: searchable.length,
    };
  }, [data, searchTerm, category]);

  const hasEvents = upcomingEvents.length > 0 || pastEvents.length > 0;

  return (
    <div className="relative min-h-screen overflow-hidden bg-[linear-gradient(180deg,#f8fbff_0%,#ffffff_45%,#f8fafc_100%)] text-slate-900">
      <section className="relative px-4 pb-14 pt-24 sm:px-6 lg:px-8 lg:pt-28">
        <div className="eh-premium-grid pointer-events-none absolute inset-0 opacity-[0.12]" />
        
        <div className="pointer-events-none absolute -left-24 top-20 h-[300px] w-[300px] sm:h-[500px] sm:w-[500px] bg-[radial-gradient(closest-side,rgba(199,210,254,0.4),transparent)]" />
        <div className="pointer-events-none absolute -right-24 top-10 h-[400px] w-[400px] sm:h-[600px] sm:w-[600px] bg-[radial-gradient(closest-side,rgba(165,243,252,0.4),transparent)]" />

        <div className="relative z-10 mx-auto max-w-7xl">
          <div className="mb-6 sm:mb-8 rounded-2xl sm:rounded-[1.6rem] border border-slate-200/80 bg-white/90 p-4 shadow-[0_18px_55px_rgba(15,23,42,0.08)] sm:p-5 lg:p-6">
            <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
              <div>
                <div className="inline-flex items-center gap-1.5 sm:gap-2 rounded-full bg-indigo-50 px-3 py-1.5 text-[10px] sm:text-xs font-black uppercase tracking-[0.18em] text-indigo-600">
                  <Filter size={14} className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
                  Browse Events
                </div>

                <h1 className="mt-2 text-2xl font-black tracking-tight text-slate-950 sm:mt-3 sm:text-3xl lg:text-4xl">
                  Explore Events
                </h1>

                <p className="mt-1 text-xs font-semibold text-slate-500 sm:text-sm">
                  {filteredCount} events available based on your search.
                </p>
              </div>

              <div className="w-full lg:max-w-xl">
                <div className="relative">
                  <Search
                    className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400 sm:left-4 sm:h-5 sm:w-5"
                  />

                  <input
                    type="search"
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    placeholder="Search event, category or location..."
                    className="h-12 w-full rounded-xl border border-slate-200 bg-slate-50 pl-10 pr-10 text-xs font-semibold text-slate-800 outline-none transition-all placeholder:text-slate-400 focus:border-indigo-300 focus:bg-white focus:ring-4 focus:ring-indigo-100 sm:h-14 sm:rounded-2xl sm:pl-12 sm:pr-12 sm:text-sm"
                  />

                  {inputValue && (
                    <button
                      type="button"
                      onClick={() => {
                        setInputValue("");
                        setSearchTerm("");
                      }}
                      className="absolute right-2 top-1/2 -translate-y-1/2 rounded-full p-1.5 text-slate-400 transition hover:bg-slate-100 hover:text-slate-700 sm:right-3 sm:p-2"
                      aria-label="Clear search"
                    >
                      <X size={16} />
                    </button>
                  )}
                </div>
              </div>
            </div>

            <div className="mt-4 flex gap-2 overflow-x-auto pb-1 sm:mt-5 sm:pb-2 [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
              {categoryOptions.map((item) => (
                <button
                  key={item}
                  type="button"
                  onClick={() => setCategory(item)}
                  className={`shrink-0 rounded-full px-3.5 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] transition-all sm:px-4 sm:py-2 sm:text-xs ${
                    category === item
                      ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/25 sm:shadow-lg"
                      : "border border-slate-200 bg-white text-slate-500 hover:border-indigo-200 hover:bg-indigo-50 hover:text-indigo-700"
                  }`}
                >
                  {item}
                </button>
              ))}
            </div>
          </div>

          {isLoading ? (
            <div className="flex min-h-[45vh] flex-col items-center justify-center gap-4">
              <div className="rounded-full bg-white p-4 shadow-xl shadow-indigo-100 sm:p-5">
                <Loader2 className="h-8 w-8 animate-spin text-indigo-600 sm:h-11 sm:w-11" />
              </div>

              <p className="animate-pulse text-sm font-bold text-slate-500 sm:text-base">
                Loading events...
              </p>
            </div>
          ) : error ? (
            <ErrorState title="Could not load events" description={error} />
          ) : !hasEvents ? (
            <div className="mx-auto mt-8 max-w-2xl rounded-[1.5rem] border border-slate-200 bg-white p-8 text-center shadow-xl shadow-slate-200/60 sm:rounded-[2rem] sm:p-10">
              <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-indigo-50 sm:mb-5 sm:h-16 sm:w-16">
                <CalendarX className="h-8 w-8 text-indigo-600 sm:h-10 sm:w-10" />
              </div>

              <h3 className="text-xl font-black text-slate-950 sm:text-2xl">
                No events found
              </h3>

              <p className="mx-auto mt-2 max-w-md text-xs leading-5 text-slate-500 sm:mt-3 sm:text-sm sm:leading-6">
                {inputValue || category !== "All"
                  ? "Try changing your search term or selecting a different category."
                  : "Published events will appear here once they are available."}
              </p>

              {(inputValue || category !== "All") && (
                <button
                  type="button"
                  onClick={() => {
                    setInputValue("");
                    setSearchTerm("");
                    setCategory("All");
                  }}
                  className="mt-5 rounded-full bg-slate-950 px-5 py-2.5 text-xs font-black text-white transition-all hover:-translate-y-0.5 hover:bg-indigo-600 sm:mt-6 sm:px-6 sm:py-3 sm:text-sm"
                >
                  Reset Filters
                </button>
              )}
            </div>
          ) : (
            <div className="mt-6 space-y-10 sm:mt-8 sm:space-y-12">
              {upcomingEvents.length > 0 && (
                <div>
                  <div className="mb-4 flex flex-col gap-3 sm:mb-5 sm:flex-row sm:items-end sm:justify-between">
                    <div>
                      <div className="flex items-center gap-3">
                        <span className="flex h-10 w-10 items-center justify-center rounded-[1rem] bg-indigo-50 sm:h-11 sm:w-11 sm:rounded-2xl">
                          <CalendarCheck className="h-5 w-5 text-indigo-600 sm:h-6 sm:w-6" />
                        </span>

                        <div>
                          <p className="text-[10px] font-black uppercase tracking-[0.18em] text-indigo-500 sm:text-xs">
                            Live Opportunities
                          </p>
                          <h2 className="text-xl font-black text-slate-950 sm:text-2xl">
                            Upcoming Events
                          </h2>
                        </div>
                      </div>
                    </div>

                    <span className="w-fit rounded-full border border-indigo-100 bg-indigo-50 px-3 py-1.5 text-xs font-black text-indigo-600 sm:px-4 sm:py-2 sm:text-sm">
                      {upcomingEvents.length} upcoming
                    </span>
                  </div>

                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 sm:gap-6 lg:grid-cols-3 xl:grid-cols-4">
                    {upcomingEvents.map((item, index) => (
                      <EventCard
                        key={item.id || `${item.EventName}-${index}`}
                        event={item}
                        index={index}
                      />
                    ))}
                  </div>
                </div>
              )}

              {pastEvents.length > 0 && (
                <div className="rounded-[1.5rem] border border-slate-200 bg-white p-4 shadow-sm sm:rounded-[2rem] sm:p-6">
                  <div className="mb-4 flex flex-col gap-3 sm:mb-5 sm:flex-row sm:items-end sm:justify-between">
                    <div className="flex items-center gap-3">
                      <span className="flex h-10 w-10 items-center justify-center rounded-[1rem] bg-slate-100 sm:h-11 sm:w-11 sm:rounded-2xl">
                        <History className="h-5 w-5 text-slate-600 sm:h-6 sm:w-6" />
                      </span>

                      <div>
                        <p className="text-[10px] font-black uppercase tracking-[0.18em] text-slate-400 sm:text-xs">
                          Archive
                        </p>
                        <h2 className="text-xl font-black text-slate-950 sm:text-2xl">
                          Past Events
                        </h2>
                      </div>
                    </div>

                    <span className="w-fit rounded-full border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-black text-slate-500 shadow-sm sm:px-4 sm:py-2 sm:text-sm">
                      {pastEvents.length} completed
                    </span>
                  </div>

                  <div className="grid opacity-95 grid-cols-1 gap-4 sm:grid-cols-2 sm:gap-6 lg:grid-cols-3 xl:grid-cols-4">
                    {pastEvents.map((item, index) => (
                      <EventCard
                        key={item.id || `${item.EventName}-${index}`}
                        event={item}
                        index={index}
                      />
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </section>
    </div>
  );
};

export default AllEvents;